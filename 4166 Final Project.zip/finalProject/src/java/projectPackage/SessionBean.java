/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectPackage;

import java.io.Serializable;
/**
 *
 * @author jessd
 */
public class SessionBean implements Serializable {
    private String firstName;
    private String lastName;
    private String emailAddress;
    private String userName;
    private int userId;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

     public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress= emailAddress;
    }
    
    public String getUserName() {
        return userName;
    }

    public void setUserName(String username) {
        this.userName= username;
    }

    public int getuserId() {
        return userId;
    }

    public void setUserID(int userId) {
        this.userId = userId;
    }

    public SessionBean() {
        //this is here because it is a bean and so it should be here
    }

}
