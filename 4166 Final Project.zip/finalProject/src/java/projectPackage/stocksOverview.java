/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectPackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author jdraper6
 */
public class stocksOverview extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            double total = 0;
            String errorMessage = "";
          String feedback = request.getParameter("stocks");

          HttpSession userSession = request.getSession();

           Investor newInvestor = (Investor)userSession.getAttribute("sessionThing");

             if (newInvestor == null)
            {



               response.sendRedirect("index?rdir=1");
            }

             else {
                String buySellOutput ="";
                try{
                     
                double amountOwed = 0;
                String stockName="";
                int amtCheck=0;
                int amtLeft =0;
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                Connection connect = DriverManager.getConnection("jdbc:mysql://localhost/stockexchange"+ "?user=User1&password=pass-word");
                Statement statement = connect.createStatement();
                String selectQuery = "SELECT s.colStockPrice,s.colStockName, s.colStockID,us.colStockAmt FROM stocks s LEFT JOIN userstocks us on us.colStockID = s.colStockID WHERE us.colUserID="+newInvestor.userId+" AND s.colStockID="+feedback+";";
                ResultSet resultSet = statement.executeQuery(selectQuery);
                while(resultSet.next()!=false){
                    String loopStockPrice = resultSet.getString("colStockPrice"); 
                    String loopStockAmt = resultSet.getString("colStockAmt");
                    String loopStockName= resultSet.getString("colStockName");
                  amountOwed = Double.parseDouble(request.getParameter("amountEntered"))* Double.parseDouble(loopStockPrice);
                 stockName = loopStockName;
                 amtCheck = Integer.parseInt(loopStockAmt);
                }
                if (request.getParameter("amountEntered")!= null){
                   if (Integer.parseInt(request.getParameter("amountEntered"))> 0){
                        amtLeft = amtCheck-Integer.parseInt(request.getParameter("amountEntered"));
                   }
                }
                  
                if ("buy".equals(request.getParameter("choice"))&& newInvestor.accountBalance >= amountOwed ){
                    statement.executeUpdate("UPDATE userstocks SET colStockAmt= colStockAmt+"+request.getParameter("amountEntered")+ " WHERE colUserID ="+newInvestor.userId+" and colStockID="+feedback+";");
                    statement.executeUpdate("Update usertable SET colAccountBalance= colAccountBalance-"+ amountOwed+ " WHERE id="+ newInvestor.userId);
                    buySellOutput ="You purchased "+request.getParameter("amountEntered")+" shares of stock in: "+ stockName+"<br>";
                }
                else if("buy".equals(request.getParameter("choice"))&& newInvestor.accountBalance <amountOwed ){
                    errorMessage = "You did not have enough funds to buy the stock. The purchase was not complete";
                }
                if("sell".equals(request.getParameter("choice"))&& amtCheck>0&& Integer.parseInt(request.getParameter("amountEntered"))<=amtCheck){
                    statement.executeUpdate("UPDATE userstocks SET colStockAmt= colStockAmt-"+request.getParameter("amountEntered")+ " WHERE colUserID ="+newInvestor.userId+" and colStockID="+feedback+";");
                    statement.executeUpdate("Update usertable SET colAccountBalance= colAccountBalance+"+ amountOwed+ " WHERE id="+ newInvestor.userId);
                    buySellOutput ="You Sold "+request.getParameter("amountEntered")+" shares of stock in: "+ stockName+" now you have " +amtLeft+"<br>";
                         }
                else if("sell".equals(request.getParameter("choice"))&& amtCheck<Integer.parseInt(request.getParameter("amountEntered"))){
                    buySellOutput ="You do not own enough stock to complete this transaction.";
                    }
                 }
                 catch(Exception e)
                {
                    out.println("DATABASE PROBLEM: " + e);
                }
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>4166 Project for Jessica Draper</title>"); 
                out.println("<link rel=\"stylesheet\" type=\"text/css\" href= projectStyle.css>");
                out.println("</head>");
                out.println("<body>");
                int bSOLength = buySellOutput.length();
                if( bSOLength > 0 ){
                    out.println(buySellOutput);
                }
                out.println("Welcome "+ newInvestor.firstName+"<br/>"); 
                out.println("<form method =\"post\" action=\"stocksOverview\" name =\"form1\"><br>");
                out.println("<input type=\"submit\" name=\"leavingSite\" value=\"Log out\">");
                out.println("</form>");
                out.println("<nav>");
                out.println("<ul>");
                out.println("<li><a href=\"index\">Home</a></li>");
                out.println(" <li><a href=\"stocksOverview\">Buy and Sell</a></li>");
                out.println("<li><a href=\"holdingsPage\">Customer Holdings</a></li>"); 
                out.println("</ul>");
                out.println("</nav>");
                out.println("<form method =\"post\" action=\"stocksOverview\"><br>");
                
                if("Log out".equals(request.getParameter("leavingSite")))
                {
                response.sendRedirect("index?rdir=0");
                }
                out.println("<header><h1>Stocks Available to Buy</h1></header>");
               
                
                if(errorMessage.length()>1){
                    out.println(errorMessage+"<br>");
                }
                 try{
                      String balance= "";
                      Class.forName("com.mysql.jdbc.Driver").newInstance();
                      Connection connect = DriverManager.getConnection("jdbc:mysql://localhost/stockexchange"+ "?user=User1&password=pass-word");
                      Statement statement = connect.createStatement();
                      String selectQuery = "select s.colStockID, s.colStockName, s.colTickerSymbol, s.colStockPrice, s.colCompanyType, s.colStockID, u.colAccountBalance from usertable u join stocks s on 1=1 where u.id="+newInvestor.userId+";";
                      ResultSet resultSet = statement.executeQuery(selectQuery);
                             
                    
                
                out.println("</form>");
           
                out.println("<section class = \"center\">");
                out.println("<form method =\"post\" action=\"stocksOverview\"> ");
                out.println("<table id ='table1'>");
                out.println(" <th>Company Name</th>");
                out.println("<th>Ticker Symbol</th>");
                out.println("<th>Type of Company</th>");
                out.println("<th>Value</th>");
                out.println("</tr>");
                String stockPickList="";
                     while(resultSet.next()!=false){
                   out.println("<tr>");
                   out.println("<td>"+resultSet.getString("colStockName")+"</td>");
                   out.println("<td>"+resultSet.getString("colTickerSymbol")+"</td>");
                   out.println("<td>"+resultSet.getString("colCompanyType")+"</td>");
                   out.println("<td>$"+resultSet.getString("colStockPrice")+"</td>");
                   out.println("</tr>"); 
                   stockPickList=stockPickList+
                           "<option value =\""+ resultSet.getString("colStockID")+"\">"+
                           resultSet.getString("colStockName") + "</option>";
                           String loopAccountBalance= resultSet.getString("colAccountBalance");
                           balance = loopAccountBalance;
                   
                   }
                out.println("</table><br>");
                out.println("Account Balance: "+ balance+"<br>");
                out.println("Please choose which stock you would like to buy or sell.<br>");
                out.println("<form>");
                out.println("<select name=\"stocks\">");
                out.println("<option value=\"null\">Please Choose</option>");
                out.println(stockPickList);
                out.println("</select>");
                out.println("<input type=\"radio\" name=\"choice\" value=\"buy\" checked>Buy");
                out.println("<input type=\"radio\" name=\"choice\" value=\"sell\" checked>Sell");
                out.println("<br>How many?");
                out.println("<input type=\"number\" min=\"0\" name=\"amountEntered\"><br>");
                out.println("<input type=\"submit\"value=\"Submit\">");
                out.println("</form>");
                out.println("</section>");
                out.println("</body>");
                out.println("</html>");
                
                
                
             }
                   catch(Exception e)
                {
                    out.println("DATABASE PROBLEM: " + e);
                }
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
