/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectPackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author jessd
 */
public class registrationPage extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            
            //Gets the session of the user
            HttpSession userSession = request.getSession();
            
            //Checks to see if user is logged in
            Investor isLoggedIn = (Investor)userSession.getAttribute("sessionThing");
            
            //If the person isn\"t logget in, it allows them to register.
            if(isLoggedIn == null)
            {
               
               String firstName = request.getParameter("firstName"); 
               String lastName = request.getParameter("lastName");
               String emailAddress = request.getParameter("emailAddress");
               String username = request.getParameter("username");
               String password = request.getParameter("password");
               String subCheck = request.getParameter("subCheck");
               String fNameStyle;
               String lNameStyle;
               String emailStyle;
               String uNameStyle;
               String pwStyle;
               
               
            if( firstName == null || firstName.equals("")||
                lastName == null || lastName.equals("")|| 
                emailAddress== null || emailAddress.equals("")|| !emailAddress.contains("@") || !emailAddress.contains(".") ||
                username == null || username.equals("") || 
                password == null || password.equals("") )
            {
                if( (firstName == null || firstName.equals("")) && (subCheck!= null && subCheck.equals("0x10"))){
                    fNameStyle = "requiredShow";
                } else{
                   fNameStyle = "requiredHide"; 
                }
                 if( (lastName == null || lastName.equals("")) && (subCheck!= null && subCheck.equals("0x10"))){
                    lNameStyle = "requiredShow";
                } else{
                   lNameStyle = "requiredHide"; 
                }
                 if( (emailAddress == null || emailAddress.equals("")) && (subCheck!= null && subCheck.equals("0x10"))){
                    emailStyle = "requiredShow";
                }   else if(emailAddress != null && (!emailAddress.contains("@") || !emailAddress.contains(".")) && (subCheck!= null && subCheck.equals("0x10"))){
                    emailStyle = "requiredShow";
                    }
                 else{
                   emailStyle = "requiredHide"; 
                }  
                 if((username == null || username.equals("")) && (subCheck!= null && subCheck.equals("0x10"))){
                    uNameStyle = "requiredShow";
                } else{
                   uNameStyle = "requiredHide"; 
                }
                 if( (password == null || lastName.equals("")) && (subCheck!= null && subCheck.equals("0x10"))){
                    pwStyle = "requiredShow";
                } else{
                   pwStyle = "requiredHide"; 
                }
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<meta charset=\"UTF-8\">");
                out.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
                out.println("<title>Servlet registrationPage</title>");            
                out.println("<link rel=\"stylesheet\" type=\"text/css\" href= projectStyle.css>");
                out.println("<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js\"></script>");
                out.println("<script src=\"projectJavaScript.js\"></script>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h1>New User Registration</h1>");
                out.println("<section class = \"center\">");
                out.println("<p>Please set up your new account. All Form fields have to be filled out.");
                out.println("<form action =\"registrationPage\" method=\"post\">");
                out.println("<input type =\"hidden\" name=\"subCheck\" value=\"0x10\">");
                out.println("First name: <br>");
                out.println("<input type=\"text\" name =\"firstName\"><div class = \""+ fNameStyle +"\">*Required</div><br>");
                out.println("Last name: <br>");
                out.println("<input type=\"text\" name =\"lastName\"><div class = \""+ lNameStyle +"\">*Required</div><br>");
                out.println("Email:<br>");
                out.println("<input type=\"text\" name=\"emailAddress\"><div class = \""+ emailStyle +"\">*Required</div><br>");
                out.println("User name:<br>");
                out.println("<input type=\"text\" name=\"username\" id=\"username\"><div class = \""+ uNameStyle +"\">*Required</div><div id =\"checkRes\"></div><br>");
                        
                out.println("create a password:<br>");
                out.println("<input type=\"password\" name =\"password\"><div class = \""+ pwStyle +"\">*Required</div><br><br>");
                //out.println("<input type=\"checkbox\" name=\"agree\"> By clicking here I agree to the the terms and conditions outlined by the <a href = \"EULA.html\">EULA</a> that no one ever reads.<br>");
                out.println("<input type=\"submit\" value=\"Create Account\">");
                out.println("<input type=\"reset\" value=\"Cancel\">");
                out.println("</form>");
                out.println("</section>");
                out.println("</body>");
                out.println("</html>");
                
               
                
           }
            else
            {
                
                    Investor anInvestor = new Investor();
                    anInvestor.firstName = firstName;
                    anInvestor.lastName = lastName;
                    anInvestor.emailAddress = emailAddress;
                    anInvestor.password = password;
                    anInvestor.username = username;
                    //saves Investor object into hasmap
                    //tradingFloorMap.theTradingFloorMap.put(username,anInvestor);
                    //puts the Investor object into the session
                    /*userSession.setAttribute("sessionThing",anInvestor);
                    out.println("<!DOCTYPE html>");
                    out.println("<html>");
                    out.println("<head>");
                    out.println("<meta charset=\"UTF-8\">");
                    out.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
                    out.println("<title>Servlet registrationPage</title>");            
                    out.println("<link rel=\"stylesheet\" type=\"text/css\" href= projectStyle.css>");
                    out.println("</head>");
                    out.println("<body>");
                    out.println("<h1>Account created and you are logged in.<br/>");
                    out.println("Click <a href=\"holdingsPage\">here</a> to continue to your holdings page.");
                    out.println("</body>");
                    out.println("</html>");*/
                    userSession.invalidate();//invalidates the session
                    response.sendRedirect("index?rdir=1");//sends the user back to log in so that info in the table will show up upon log in
                    
                    try
                {
                   
                    Class.forName("com.mysql.jdbc.Driver").newInstance();
                    // Setup the connection with the DB
                    Connection connect = DriverManager.getConnection("jdbc:mysql://localhost/stockexchange"+ "?user=User1&password=pass-word");
                    // Statements allow to issue SQL queries to the database
                    Statement statement = connect.createStatement();
                    // Result set get the result of the SQL query
                    int numRowsChanged = statement.executeUpdate("insert into stockexchange.usertable (colFirstName, colLastName, colEmailAddress, colPassword, colUserName) VALUES (" +  "'" + firstName +  "'" + ", '" + lastName + "', '" + emailAddress + "', '" + password + "'" + ", '"+ username+"');");
                    out.println(numRowsChanged + " rows inserted.");
                    
                    connect.close();
                }
                catch(Exception e)
                {
                    out.println("DATABASE PROBLEM");
                    e.printStackTrace();
                }
                
            }
            }
        
    
        else{
            
            out.println("<h1>You are already logged in");
            out.println("Click <a href=\"holdingsPage\">here</a>to continue to your holdings page.");
                }
            
          
            
            }
        }
        
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
