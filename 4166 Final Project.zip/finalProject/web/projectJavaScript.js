/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

    $(document).ready(function() {  
      
            //the min chars for username  
            var min_chars = 3;  
      
            //result texts  
            var characters_error = 'Minimum amount of chars is 3';  
            var checking_html = 'Checking...';  
      
            //when button is clicked  
            $('#username').blur(function(){  
                //run the character number check  
                check_availability();  
            });  
      
      });  
      
    //function to check username availability  
    function check_availability(){  
      
            //get the username  
            var username = $('#username').val();  
            if(username.length>0){
            //use ajax to run the check  
                $.ajax({
                   type: "POST",
                   url: "userNameCheck",
                   data: { username: username},
                   success: resultCheck
               });
            }
    }  
    
    function resultCheck(data)
    {
       // window.alert(data);
        var thediv = document.getElementById("checkRes");
        if(data==0){
            thediv.innerHTML = "User name is available";
        }
        else if(data > 0){
            thediv.innerHTML = "User name is not available";
        }
        else if(data ==-1){
            thediv.innerHTML = "Problem validating user name.";
        }
    }