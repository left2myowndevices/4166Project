/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectPackage;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author jdraper6
 */
public class stocksOverview extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            double total = 0;
            String errorMessage = "";
          

          HttpSession userSession = request.getSession();

           Investor newInvestor = (Investor)userSession.getAttribute("sessionThing");

             if (newInvestor == null)
            {



               response.sendRedirect("index?rdir=1");
            }

             else {
                if ("Buy".equals(request.getParameter("buy1")) && Double.parseDouble(request.getParameter("number1")) > 0){
                    total = (newInvestor.priceOfStock1 * Double.parseDouble(request.getParameter("number1")));
                            if (newInvestor.accountBalance> total)
                            {
                                newInvestor.accountBalance = newInvestor.accountBalance - total;
                                newInvestor.sharesOfStock1 = newInvestor.sharesOfStock1 + Integer.parseInt(request.getParameter("number1"));
                                errorMessage = "You now have " + newInvestor.sharesOfStock1 + " shares of Massive Dynamic, and your new account balance is: " + newInvestor.accountBalance;
                            }
                            else 
                            {
                                errorMessage = "You did not have enough funds to buy the stock. The purchase was not complete";
                            }
                }    
                else if ("Sell".equals(request.getParameter("sell1")))  
                {
                    if (newInvestor.sharesOfStock1<Integer.parseInt(request.getParameter("number1")))
                    {
                        errorMessage = "You do not own enough stock to complete this transaction";
                    }
                    else
                    {
                        total = newInvestor.priceOfStock1 * Integer.parseInt(request.getParameter("number1"));
                        newInvestor.accountBalance = newInvestor.accountBalance + total;
                        newInvestor.sharesOfStock1 = newInvestor.sharesOfStock1 - Integer.parseInt(request.getParameter("number1"));
                        errorMessage = "You now have " + newInvestor.sharesOfStock1 + "shares of Massive Dynamic, and your new account balance is: " + newInvestor.accountBalance;
                    }
                }
                else if ("Buy".equals(request.getParameter("buy2")) && Double.parseDouble(request.getParameter("number2")) > 0){
                    total = (newInvestor.priceOfStock2 * Double.parseDouble(request.getParameter("number2")));
                            if (newInvestor.accountBalance> total)
                            {
                                newInvestor.accountBalance = newInvestor.accountBalance - total;
                                newInvestor.sharesOfStock2 = newInvestor.sharesOfStock2 + Integer.parseInt(request.getParameter("number2"));
                                errorMessage = "You now have " + newInvestor.sharesOfStock2 + " shares of Umbrella Corporation, and your new account balance is: " + newInvestor.accountBalance;
                            }
                            else 
                            {
                                errorMessage = "You did not have enough funds to buy the stock. The purchase was not complete";
                            }
                }    
                else if ("Sell".equals(request.getParameter("sell2")))  
                {
                    if (newInvestor.sharesOfStock2<Integer.parseInt(request.getParameter("number2")))
                    {
                        errorMessage = "You do not own enough stock to complete this transaction";
                    }
                    else
                    {
                        total = newInvestor.priceOfStock2 * Integer.parseInt(request.getParameter("number2"));
                        newInvestor.accountBalance = newInvestor.accountBalance + total;
                        newInvestor.sharesOfStock2 = newInvestor.sharesOfStock2 - Integer.parseInt(request.getParameter("number2"));
                        errorMessage = "You now have " + newInvestor.sharesOfStock2 + "shares of Umbrella Corporation, and your new account balance is: " + newInvestor.accountBalance;
                    }
                }
                else if ("Buy".equals(request.getParameter("buy3")) && Double.parseDouble(request.getParameter("number3")) > 0){
                    total = (newInvestor.priceOfStock3 * Double.parseDouble(request.getParameter("number3")));
                            if (newInvestor.accountBalance> total)
                            {
                                newInvestor.accountBalance = newInvestor.accountBalance - total;
                                newInvestor.sharesOfStock3 = newInvestor.sharesOfStock3 + Integer.parseInt(request.getParameter("number3"));
                                errorMessage = "You now have " + newInvestor.sharesOfStock3 + " shares of Vault-Tech, and your new account balance is: " + newInvestor.accountBalance;
                            }
                            else 
                            {
                                errorMessage = "You did not have enough funds to buy the stock. The purchase was not complete";
                            }
                }    
                else if ("Sell".equals(request.getParameter("sell3")))  
                {
                    if (newInvestor.sharesOfStock3<Integer.parseInt(request.getParameter("number3")))
                    {
                        errorMessage = "You do not own enough stock to complete this transaction";
                    }
                    else
                    {
                        total = newInvestor.priceOfStock3 * Integer.parseInt(request.getParameter("number3"));
                        newInvestor.accountBalance = newInvestor.accountBalance + total;
                        newInvestor.sharesOfStock3 = newInvestor.sharesOfStock3 - Integer.parseInt(request.getParameter("number3"));
                        errorMessage = "You now have " + newInvestor.sharesOfStock3 + "shares of Vault-Tech, and your new account balance is: " + newInvestor.accountBalance;
                    }
                }
                else if ("Buy".equals(request.getParameter("buy4")) && Double.parseDouble(request.getParameter("number4")) > 0){
                    total = (newInvestor.priceOfStock4 * Double.parseDouble(request.getParameter("number4")));
                            if (newInvestor.accountBalance> total)
                            {
                                newInvestor.accountBalance = newInvestor.accountBalance - total;
                                newInvestor.sharesOfStock4 = newInvestor.sharesOfStock4 + Integer.parseInt(request.getParameter("number4"));
                                errorMessage = "You now have " + newInvestor.sharesOfStock4 + " shares of Stark Industries, and your new account balance is: " + newInvestor.accountBalance;
                            }
                            else 
                            {
                                errorMessage = "You did not have enough funds to buy the stock. The purchase was not complete";
                            }
                }    
                else if ("Sell".equals(request.getParameter("sell4")))  
                {
                    if (newInvestor.sharesOfStock4<Integer.parseInt(request.getParameter("number4")))
                    {
                        errorMessage = "You do not own enough stock to complete this transaction";
                    }
                    else
                    {
                        total = newInvestor.priceOfStock4 * Integer.parseInt(request.getParameter("number4"));
                        newInvestor.accountBalance = newInvestor.accountBalance + total;
                        newInvestor.sharesOfStock4 = newInvestor.sharesOfStock4 - Integer.parseInt(request.getParameter("number4"));
                        errorMessage = "You now have " + newInvestor.sharesOfStock4 + "shares of Stark Industries, and your new account balance is: " + newInvestor.accountBalance;
                    }
                }
                 
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>4166 Project for Jessica Draper</title>"); 
                out.println("<link rel=\"stylesheet\" type=\"text/css\" href= projectStyle.css>");
                out.println("</head>");
                out.println("<body>");
                out.println("Welcome "+ newInvestor.firstName+"<br/>"); 
                 out.println("<form method =\"post\" action=\"stocksOverview\"><br>");
                 out.println("<input type=\"submit\" name=\"leavingSite\" value=\"Log out\">");
                if("Log out".equals(request.getParameter("leavingSite")))
                {
                response.sendRedirect("index?rdir=0");
                }
                out.println("<header><h1>Stocks Available to Buy</h1></header>");
               
                
                if(errorMessage.length()>1){
                    out.println(errorMessage+"<br>");
                }
                out.println("</form>");
                out.println("<nav>");
                out.println("<ul>");
                out.println("<li><a href=\"index\">Home</a></li>");
                out.println(" <li><a href=\"stocksOverview\">Buy and Sell</a></li>");
                out.println("<li><a href=\"holdingsPage\">Customer Holdings</a></li>"); 
                out.println("</ul>");
                out.println("</nav>");
                out.println("<section class = \"center\">");
                out.println("<form method =\"post\" action=\"stocksOverview\"> ");
                out.println("<table id ='table1'>");
                out.println("<tr>");
                out.println(" <th>Company Name</th>");
                out.println("<th>Ticker Symbol</th>");
                out.println("<th>Type of Company</th>");
                out.println("<th>Value</th>");
                out.println("</tr>");
                out.println("<tr>");        
                out.println("<td>Massive Dynamic</td>");
                out.println("<td>MMD</td>");
                out.println("<td>Biotech</td>");
                out.println("<td>$54.50</td>");
                out.println("<td>");
                out.println("<input type=\"number\"min=\"0\" name=\"number1\">");                
                out.println("<input type=\"submit\" name=\"buy1\" value=\"Buy\">");                 
                out.println("<input type=\"submit\" name=\"sell1\" value=\"Sell\">");
                out.println("</td>");  
                out.println("</td>");
                out.println("</tr>");
                out.println("<tr>");
                out.println("<td>Umbrella Corporation</td>");
                out.println("<td>UMC</td>");
                out.println("<td>Biotech</td>");
                out.println("<td>$999.99</td>");
                out.println("<td>");
                out.println("<input type=\"number\" min=\"0\" name=\"number2\">  ");
                out.println("<input type=\"submit\" name=\"buy2\" value=\"Buy\">");
                out.println("<input type=\"submit\" name=\"sell2\" value=\"Sell\">");
                out.println("</td>");
                out.println("</tr>");
                out.println("<tr>");
                out.println("<td>Vault-Tech</td>");
                out.println("<td>VTK</td>");
                out.println("<td>Construction</td>");
                out.println("<td>$10.50</td>");
                out.println("<td>");
                out.println("<input type=\"number\" min=\"0\" name=\"number3\"> ");
                out.println("<input type=\"submit\" name=\"buy3\" value=\"Buy\">");
                out.println("<input type=\"submit\" name=\"sell3\" value=\"Sell\">");
                out.println("</td>");
                out.println("</tr>");
                out.println("<tr>");
                out.println("<td>Stark Industries</td>");
                out.println("<td>STI</td>");
                out.println("<td>Aerospace/Defense</td>");
                out.println("<td>$75.69</td>");
                out.println("<td>");
                out.println("<input type=\"number\" min=\"0\" name=\"number4\">  ");
                out.println("<input type=\"submit\" name=\"buy4\" value=\"Buy\">");
                out.println("<input type=\"submit\" name=\"sell4\" value=\"Sell\">");
                out.println("</td>");
                out.println("</tr>");
                out.println(" </table>");
                out.println("</form>");
                out.println("</section>");
                out.println("</body>");
                out.println("</html>");
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
