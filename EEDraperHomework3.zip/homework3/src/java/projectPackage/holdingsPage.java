/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectPackage;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author jessd
 */
public class holdingsPage extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            
            HttpSession userSession = request.getSession();
            
            Investor newInvestor = (Investor)userSession.getAttribute("sessionThing");
           
            String logOutParam =  request.getParameter("leavingSite");
        if(logOutParam != null && "Log out".equals(logOutParam))
        {
        response.sendRedirect("index?rdir=0");
        }
        else if (newInvestor == null){
            response.sendRedirect("index?rdir=1");
        }
        else{
            String moneyAdd = null;
            if(request.getParameter("addCheck")!= null){
                String addCheck = request.getParameter("addCheck");
                if ("yes".equals(addCheck)){
                   int amount = Integer.parseInt(request.getParameter("amount"));
                   //out.println("test: "+ amount);
                   newInvestor.accountBalance = newInvestor.accountBalance + amount;
                   moneyAdd = "$"+amount + " has been added to your account.";
                }
            }
            
            newInvestor.totalPortfolioValue = newInvestor.totalPortfolioValue + (newInvestor.sharesOfStock1 * newInvestor.priceOfStock1)+(newInvestor.sharesOfStock2 * newInvestor.priceOfStock2)+(newInvestor.sharesOfStock3 * newInvestor.priceOfStock3)+(newInvestor.sharesOfStock4 * newInvestor.priceOfStock4);
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<link rel=\"stylesheet\" type=\"text/css\" href= projectStyle.css>");
            out.println("<meta charset=\"UTF-8\">");
            out.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
            out.println("<title>4166 Project for Jessica Draper</title>"); 
            out.println("</head>");
            out.println("<body>");
            out.println("Welcome "+ newInvestor.firstName+"<br/>"); 
            out.println("<form method =\"post\" action=\"holdingsPage\" name =\"form1\"><br>");
            out.println("<input type=\"submit\" name=\"leavingSite\" value=\"Log out\">");
            out.println("</form>");
            out.println("<div class =\"userInfo\">");
            out.println("User Name: "+newInvestor.username+"<br>");
            out.println(newInvestor.firstName +" "+ newInvestor.lastName+"<br>");
            out.println("Email Addess:" + newInvestor.emailAddress+"<br>");
            out.println("</div>");
            
            out.println("<nav>");
            out.println("<ul>");   
            out.println("<li><a href=\"index\">Home</a></li>");
            out.println("<li><a href=\"stocksOverview\">Buy and Sell</a></li>");
            out.println("<li><a href=\"holdingsPage\">Customer Holdings</a></li>");
            out.println("</ul>");
            out.println("<section class = \"center\"<p>Here you will find information about your portfolio.  Your stocks are listed below.</p>");
            out.println("<table>");
            out.println("<tr>");
            out.println("<th>Stock Name</th>");
            out.println("<th>Current Price</th>");
            out.println("<th>Shares Owned </th>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<td>Massive Dynamic</td>");
            out.println("<td>$54.50</td>");
            out.println("<td>"+ newInvestor.sharesOfStock1+"</td>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<td>Umbrella Corporation</td>");
            out.println("<td>$999.99</td>");
            out.println("<td>"+ newInvestor.sharesOfStock2+"</td>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<td>Vault-Tech</td>");
            out.println("<td>$10.50</td>");
            out.println("<td>"+newInvestor.sharesOfStock3+"</td>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<td>Stark Industries</td>");
            out.println("<td>$75.69</td>");
            out.println("<td>"+newInvestor.sharesOfStock4+"</td>");
            out.println("</tr>");
            out.println("</table><br/><br/>");
             out.println("<strong>Total Portfolio Value:$ "+ newInvestor.totalPortfolioValue+"</strong><br>" );
            if(moneyAdd != null){
            out.println("<strong>"+moneyAdd+"</strong>");
            }
            
            out.println("<h2>Account Balance: $"+newInvestor.accountBalance +"</h2><br>");
            
            out.println("would you like to add money to your account?<br>");
            out.println("<form action =\"holdingsPage\" method=\"post\" name =\"form2\">");
            out.println("<input type=\"hidden\" name=\"addCheck\" value=\"yes\">");
            out.println("<input type=\"number\" name=\"amount\" min=\"0\" max=\"10000\" step=\"100\">");
            out.println("<input type=\"submit\" value=\"Add Money\">");
            out.println("</form>");
            
            out.println("</section>");
            out.println("</body>");
            out.println("</html>");
                if (request.getParameter("amount").equals(0)){
                out.println("no money was added to your account");
                }
        }
    }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
