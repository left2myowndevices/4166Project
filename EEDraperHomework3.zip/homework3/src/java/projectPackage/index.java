/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectPackage;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 *
 * @author jessd
 */
public class index extends HttpServlet {

   

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            /* TODO output your page here. You may use following sample code. */
            
            //Checks to see if username has been sent
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            
            
            //Checks to see if redirected
            String rdir = request.getParameter("rdir");
            
            //checks to see if user is logging off
            String leavingSite = request.getParameter("leavingSite");
            
            if(leavingSite == null|| leavingSite.equals(""))
            {
                HttpSession checkSession = request.getSession();
                
                //Checks to see if the user has a session that already exists
                Investor testInvestor = (Investor)checkSession.getAttribute("sessionThing");
               
                
                if(username == null|| username.equals("")&& password == null || password.equals(""))
                {
                    out.println("<!DOCTYPE html>");
                    out.println("<html>");
                    out.println("<head>");  
                    out.println("<link rel=\"stylesheet\" type=\"text/css\" href= projectStyle.css>");
                    out.println("<title>4166 Project for Jessica Draper</title>");            
                    out.println("</head>");
                    out.println("<body><div>Project Home</div>");
                    if ("1".equals(rdir)){
                        out.println("<section id = firstPage>");
                        out.println("<strong>You must log in first.</strong>");
                    }
                    else if("0".equals(rdir))
                    {
                        out.println("<section id = firstPage>");
                        out.println("<strong>Sad to see you go. You have been Logged out</strong><br/>Click <a href=\"index\">here</a> to log back in. ");
                          //no...please no...we have no choice. I'll take the basket
                        HttpSession userSession = request.getSession();
                        userSession.invalidate();
                        testInvestor = (Investor)checkSession.getAttribute("sessionThing");
                    }
                    if (testInvestor==null){
                        out.println("<section id = firstPage>");
                        out.println("<form action =\"index\" method=\"post\"> User name: <br>");
                        out.println("<input type =\"text\" name =\"username\"><br>");
                        out.println("Password:<br>");
                        out.println("<input type =\"text\" name =\"password\"><br>");
                        out.println("<input type =\"submit\" value=\"Log in\">");
                        out.println("<input type =\"reset\" value=\"Cancel\">");
                        out.println("</form> New customer? Create an account <a href=\"registrationPage\">here</a></section>");
                    } else {
                        out.println("<nav>");
                        out.println("<ul>");
                        out.println("<li><a href=\"index\">Home</a></li>");
                        out.println(" <li><a href=\"stocksOverview\">Buy and Sell</a></li>");
                        out.println("<li><a href=\"holdingsPage\">Customer Holdings</a></li>"); 
                        out.println("</ul>");
                        out.println("</nav>");
                        out.println("<section id = firstPage>");
                        out.println("Hi "+ testInvestor.firstName+". You are logged in.<br/>"); 
                        out.println("<form method =\"post\" action=\"holdingsPage\" name =\"form1\"><br>");
                        out.println("<input type=\"submit\" name=\"leavingSite\" value=\"Log out\">");
                        out.println("</form>");
                    }
                    out.println("</section>");
                    out.println("</body>");
                    out.println("</html>");  
                }
                else
                {
                    Investor checkInvestor = tradingFloorMap.theTradingFloorMap.get(username);
                   
                   
                    out.println("<!DOCTYPE html>");
                    out.println("<html>");
                    out.println("<head>");  
                    out.println("<link rel=\"stylesheet\" type=\"text/css\" href= projectStyle.css>");
                    out.println("<title>4166 Project for Jessica Draper</title>");            
                    out.println("</head>");
                    out.println("<body><div>Project Home</div>");   //username was found in the hashmap
                    if(checkInvestor !=null && checkInvestor.username.equals(request.getParameter("username")) && checkInvestor.password.equals(request.getParameter("password"))){
                    out.println("Welcome "+ checkInvestor.firstName);
                    out.println(" You are logged in<br>");
                    out.println("<section id = firstPage>");
                    }
                    else if(checkInvestor != null && !checkInvestor.password.equals(request.getParameter("password")) && !checkInvestor.username.equals(request.getParameter("username")))
                    {
                        out.println("<strong>Either your Username or Password is incorrect.... click <a href=\"index\">here</a></section>\"</strong>.");
                    }
                    else {
                        out.println("<h1>Username does not exist. You will need to create an account <a href=\"registrationPage\">here</a></h1>");
                        //response.sendRedirect("index");
                    }
                    //gives user a session
                    HttpSession userSession = request.getSession();
                    //puts an investor object in the session basket so that it will communicate with the other servelets
                    userSession.setAttribute("sessionThing",checkInvestor);
                    /*out.println("<form action =\"index\" method=\"post\"> User name: <br>");
                    out.println("<input type =\"text\" name =\"username\"><br>");
                    out.println("Password:<br>");
                    out.println("<input type =\"text\" name =\"password\"><br>");
                    out.println("<input type =\"submit\" value=\"Log in\">");
                    out.println("<input type =\"reset\" value=\"Cancel\">");
                    out.println("</form> New customer? Create an account <a href=\"registrationPage\">here</a></section>");
                    out.println("</body>");
                    out.println("</html>");
                    
                    
                    
                        
                       out.println("<form action=\"index\" method=\"post\">");
                       out.println("<input type=\"hidden\" name=\"leavingSite\" value=\"leaving\"><br><br>");
                       out.println("<input type=\"submit\" value=\"log out\">");*/
                
                        
                }
            }
        }
                  
                
        
    }  

             
    
                    
        
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
