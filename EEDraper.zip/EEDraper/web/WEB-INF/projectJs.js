function alertHome() {
    alert("We are in the Process of updating the website. Some functionality may not be available.");
}



