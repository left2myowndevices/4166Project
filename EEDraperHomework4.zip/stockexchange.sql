create database stockexchange;
use stockexchange;
CREATE USER 'User1'@'localhost' IDENTIFIED BY 'pass-word';
GRANT ALL PRIVILEGES ON stockexchange.* TO 'User1'@'localhost';
-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 26, 2016 at 05:01 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stockexchange`
--

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

CREATE TABLE `stocks` (
  `colStockName` varchar(25) NOT NULL,
  `colCompanyType` varchar(25) NOT NULL,
  `colTickerSymbol` varchar(10) NOT NULL,
  `colStockPrice` double NOT NULL DEFAULT '0',
  `colStockID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stocks`
--

INSERT INTO `stocks` (`colStockName`, `colCompanyType`, `colTickerSymbol`, `colStockPrice`, `colStockID`) VALUES
('Massive Dynamic', 'Biotech', 'MMD', 54.5, 1),
('Umbrella Corporation', 'Biotech', 'UMC', 900, 2),
('Vault-Tech', 'Construction', 'VTK', 10.5, 3),
('Stark Industries', 'Aerospace/Defense', 'STI', 75.69, 4);

-- --------------------------------------------------------

--
-- Table structure for table `userstocks`
--

CREATE TABLE `userstocks` (
  `colUserID` int(11) NOT NULL,
  `colStockID` int(11) NOT NULL,
  `colStockAmt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userstocks`
--

INSERT INTO `userstocks` (`colUserID`, `colStockID`, `colStockAmt`) VALUES
(1, 1, 22),
(1, 2, 11),
(1, 3, 5),
(1, 4, 3);

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `id` int(11) NOT NULL,
  `colFirstName` varchar(25) NOT NULL,
  `colLastName` varchar(25) NOT NULL,
  `colEmailAddress` varchar(25) NOT NULL DEFAULT '',
  `colUserName` varchar(25) NOT NULL,
  `colPassword` varchar(25) NOT NULL,
  `colAccountBalance` double NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`id`, `colFirstName`, `colLastName`, `colEmailAddress`, `colUserName`, `colPassword`, `colAccountBalance`) VALUES
(1, 'Jessica', 'Draper', 'jdraper6@uncc.edu', 'jdraper', '1234', 2555);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `stocks`
--
ALTER TABLE `stocks`
  ADD PRIMARY KEY (`colStockID`),
  ADD UNIQUE KEY `colStockID` (`colStockID`);

--
-- Indexes for table `userstocks`
--
ALTER TABLE `userstocks`
  ADD PRIMARY KEY (`colUserID`,`colStockID`),
  ADD KEY `user stocks_ibfk_2` (`colStockID`);

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `colUserName` (`colUserName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `stocks`
--
ALTER TABLE `stocks`
  MODIFY `colStockID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `usertable`
--
ALTER TABLE `usertable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `userstocks`
--
ALTER TABLE `userstocks`
  ADD CONSTRAINT `userstocks_ibfk_1` FOREIGN KEY (`colUserID`) REFERENCES `usertable` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `userstocks_ibfk_2` FOREIGN KEY (`colStockID`) REFERENCES `stocks` (`colStockID`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
