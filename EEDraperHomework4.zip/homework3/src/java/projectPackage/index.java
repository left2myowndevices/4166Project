/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectPackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 *
 * @author jessd
 */
public class index extends HttpServlet {

   

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            /* TODO output your page here. You may use following sample code. */
            
            //Checks to see if username has been sent
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            
            
            //Checks to see if redirected
            String rdir = request.getParameter("rdir");
            
            //checks to see if user is logging off
            String leavingSite = request.getParameter("leavingSite");
            
            if(leavingSite == null|| leavingSite.equals(""))
            {
                HttpSession checkSession = request.getSession();
                
                //Checks to see if the user has a session that already exists
                Investor testInvestor = (Investor)checkSession.getAttribute("sessionThing");
               
                
                if(username == null|| username.equals("")&& password == null || password.equals(""))
                {
                    out.println("<!DOCTYPE html>");
                    out.println("<html>");
                    out.println("<head>");  
                    out.println("<link rel=\"stylesheet\" type=\"text/css\" href= projectStyle.css>");
                    out.println("<title>4166 Project for Jessica Draper</title>");            
                    out.println("</head>");
                    out.println("<body><div>Project Home</div>");
                    if (rdir !=null&&"1".equals(rdir)){
                     
                        out.println("<strong>You must log in first.</strong></section>");
                    }
                    else if(rdir !=null&&"0".equals(rdir))
                    {
                      
                        out.println("<strong>Sad to see you go. You have been Logged out</strong>");
                          //no...please no...we have no choice. I'll take the basket
                        //HttpSession userSession = request.getSession();
                        checkSession.invalidate();
                        testInvestor = null;
                    }
                    if (testInvestor==null){
                        out.println("<section id = firstPage>");
                        out.println("<form action =\"index\" method=\"post\"> User name: <br>");
                        out.println("<input type =\"text\" name =\"username\"><br>");
                        out.println("Password:<br>");
                        out.println("<input type =\"password\" name =\"password\"><br>");
                        out.println("<input type =\"submit\" value=\"Log in\">");
                        out.println("<input type =\"reset\" value=\"Cancel\">");
                        out.println("</form> New customer? Create an account <a href=\"registrationPage\">here</a></section>");
                    } else {
                        out.println("<nav>");
                        out.println("<ul>");
                        out.println("<li><a href=\"index\">Home</a></li>");
                        out.println(" <li><a href=\"stocksOverview\">Buy and Sell</a></li>");
                        out.println("<li><a href=\"holdingsPage\">Customer Holdings</a></li>"); 
                        out.println("</ul>");
                        out.println("</nav>");
                        out.println("<section id = firstPage>");
                        out.println("Hi "+ testInvestor.firstName+". You are logged in.<br/>"); 
                        out.println("<form method =\"post\" action=\"holdingsPage\" name =\"form1\"><br>");
                        out.println("<input type=\"submit\" name=\"leavingSite\" value=\"Log out\">");
                        out.println("</form>");
                    }
                    out.println("</section>");
                    out.println("</body>");
                    out.println("</html>");  
                }
                else
                {
                   try
                {
                   Investor checkInvestor = new Investor();//tradingFloorMap.theTradingFloorMap.get(username);
               
                    // This will load the MySQL driver, each DB has its own driver. You WILL NEED TO INSTALL THE DRIVER or you will get an error at runtime.
                    Class.forName("com.mysql.jdbc.Driver").newInstance();
                    // Setup the connection with the DB
                    Connection connect = DriverManager.getConnection("jdbc:mysql://localhost/stockexchange"+ "?user=User1&password=pass-word");
                    // Statements allow to issue SQL queries to the database
                    Statement statement = connect.createStatement();
                    // Result set get the result of the SQL query
                    ResultSet resultSet = statement.executeQuery("select * from stockexchange.usertable where colUserName = '"+username+"';");
                    while(resultSet.next() != false){
                        String loopUsername = resultSet.getString("colUserName");
                        String loopPassword = resultSet.getString("colPassword");
                        String loopFirstName = resultSet.getString("colFirstName");
                        String loopLastName = resultSet.getString("colLastName");
                        String loopEmailAddress = resultSet.getString("colEmailaddress");
                        String loopAccountBalance = resultSet.getString("colAccountBalance");
                        String loopUserId = resultSet.getString("id");

                        out.println("<!DOCTYPE html>");
                        out.println("<html>");
                        out.println("<head>");  
                        out.println("<link rel=\"stylesheet\" type=\"text/css\" href= projectStyle.css>");
                        out.println("<title>4166 Project for Jessica Draper</title>");            
                        out.println("</head>");
                        out.println("<body><div>Project Home</div>");   //username was found in the hashmap
                        if(loopUsername.equals(username) && loopPassword.equals(password)){
                            checkInvestor.userId=Integer.parseInt(loopUserId);
                            checkInvestor.firstName=loopFirstName;
                            checkInvestor.lastName=loopLastName;
                            checkInvestor.username=loopUsername;
                            checkInvestor.password=loopPassword;
                            checkInvestor.emailAddress=loopEmailAddress;
                            checkInvestor.accountBalance=Double.parseDouble(loopAccountBalance);
                            
                            out.println("Welcome "+ loopFirstName);
                            out.println(" You are logged in<br>");
                            out.println("<nav>");
                            out.println("<ul>");
                            out.println("<li><a href=\"index\">Home</a></li>");
                            out.println(" <li><a href=\"stocksOverview\">Buy and Sell</a></li>");
                            out.println("<li><a href=\"holdingsPage\">Customer Holdings</a></li>"); 
                            out.println("</ul>");
                            out.println("</nav>");
                        }
                        else if( !loopUsername.equals(request.getParameter("username"))){
                            out.println("<h1>Username does not exist. You will need to create an account");
                            //response.sendRedirect("index");
                        }
                        else if( !loopPassword.equals(request.getParameter("password")) && loopUsername.equals(request.getParameter("username"))){
                            out.println("<section id = firstPage>");
                            out.println("<strong> Password is incorrect.");
                            out.println("<form action =\"index\" method=\"post\"> User name: <br>");
                            out.println("<input type =\"text\" name =\"username\"><br>");
                            out.println("Password:<br>");
                            out.println("<input type =\"password\" name =\"password\"><br>");
                            out.println("<input type =\"submit\" value=\"Log in\">");
                            out.println("<input type =\"reset\" value=\"Cancel\">");
                            out.println("</form> New customer? Create an account <a href=\"registrationPage\">here</a></section>");
                        }
                        
                        //gives user a session
                        HttpSession userSession = request.getSession();
                        //puts an investor object in the session basket so that it will communicate with the other servelets
                        userSession.setAttribute("sessionThing",checkInvestor);
                                            
                    }
                    connect.close();
                }
                catch(Exception e)
                {
                    out.println("DATABASE PROBLEM: " + e);
                }
                   
                   
                    
                  
                        
                }
            }
        }
                  
                
        
    }  

             
    
                    
        
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
