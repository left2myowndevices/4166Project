/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectPackage;

/**
 *
 * @author jdraper6
 */

//sets up the investor object and sets up important things about it that will be changed during the session
public class Investor {
    public String firstName = "";
    public String lastName = "";
    public String emailAddress = "";
    public String username = "";
    public String password = "";
    public int userId;
    public double accountBalance;
    //I know there should be better names of the "stock" but laziness and reasons.
    public int sharesOfStock1 = 0;
    public int sharesOfStock2 = 0;
    public int sharesOfStock3 = 0;
    public int sharesOfStock4 = 0;
    
    
    public double priceOfStock1 = 54.50;
    public double priceOfStock2 = 900.00;
    public double priceOfStock3 = 10.50;
    public double priceOfStock4 = 75.69;

 public double totalPortfolioValue =0;
    
    
   
    
}
