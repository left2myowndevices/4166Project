/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectPackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author jessd
 */
public class holdingsPage extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            
            HttpSession userSession = request.getSession();
            
            Investor newInvestor = (Investor)userSession.getAttribute("sessionThing");
           
            String logOutParam =  request.getParameter("leavingSite");
        if(logOutParam != null && "Log out".equals(logOutParam))
        {
        response.sendRedirect("index?rdir=0");
        }
        else if (newInvestor == null){
            response.sendRedirect("index?rdir=1");
        }
        else{
            
            String moneyAdd = null;
            if(request.getParameter("addCheck")!=null){
                String addCheck = request.getParameter("addCheck");
                if ("yes".equals(addCheck)){
                   int amount = Integer.parseInt(request.getParameter("amount"));
                   //out.println("test: "+ amount);
                   newInvestor.accountBalance = newInvestor.accountBalance + amount;
                   moneyAdd = "$"+amount + " has been added to your account.<br>";
                  try{
                    Class.forName("com.mysql.jdbc.Driver").newInstance();
                    Connection connect = DriverManager.getConnection("jdbc:mysql://localhost/stockexchange"+ "?user=User1&password=pass-word");
                    Statement statement = connect.createStatement();
                    String updateQuery = "UPDATE usertable SET colAccountBalance=colAccountBalance+"+ amount+" WHERE id="+newInvestor.userId+";";
                    statement.executeUpdate(updateQuery);
                    }
                   catch(Exception e)
                {
                    out.println("DATABASE PROBLEM: " + e);
                } 
                }
            }
            
            //try block to query database for user stock holdings 
            try{
                
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                Connection connect = DriverManager.getConnection("jdbc:mysql://localhost/stockexchange"+ "?user=User1&password=pass-word");
                Statement statement = connect.createStatement();
                String selectQuery = "SELECT s.colStockName, s.colStockID, s.colStockPrice, s.colTickerSymbol, us.colStockAmt, us.colStockAmt*s.colStockPrice AS colStockValue FROM stocks s LEFT JOIN userstocks us on us.colStockID = s.colStockID WHERE us.colUserID="+newInvestor.userId+";";
                ResultSet resultSet = statement.executeQuery(selectQuery);
                
                /* TODO output your page here. You may use following sample code. */
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<link rel=\"stylesheet\" type=\"text/css\" href= projectStyle.css>");
                out.println("<meta charset=\"UTF-8\">");
                out.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
                out.println("<title>4166 Project for Jessica Draper</title>"); 
                out.println("</head>");
                out.println("<body>");
                out.println("Welcome "+ newInvestor.firstName+"<br/>"); 
                out.println("<form method =\"post\" action=\"holdingsPage\" name =\"form1\"><br>");
                out.println("<input type=\"submit\" name=\"leavingSite\" value=\"Log out\">");
                out.println("</form>");
                out.println("<nav>");
                out.println("<ul>");   
                out.println("<li><a href=\"index\">Home</a></li>");
                out.println("<li><a href=\"stocksOverview\">Buy and Sell</a></li>");
                out.println("<li><a href=\"holdingsPage\">Customer Holdings</a></li>");
                out.println("</ul></nav>");
                out.println("<div class =\"userInfo\">");
                out.println("<p>User Name: "+newInvestor.username+"<br>");
                out.println(newInvestor.firstName +" "+ newInvestor.lastName+"<br>");
                out.println("Email Addess:" + newInvestor.emailAddress+"<br></p>");
                out.println("</div>");
                out.println("<section class = \"center\"><p>Here you will find information about your portfolio.  Your stocks are listed below.</p>");
                out.println("<table>");
                out.println("<tr>");
                out.println("<th>Stock Name</th>");
                out.println("<th>Current Price</th>");
                out.println("<th>Shares Owned </th>");
                out.println("</tr>");
                double totalPortfolioValue = 0.00;
                while(resultSet.next()!=false){
                   out.println("<tr>");
                    out.println("<td>"+resultSet.getString("colStockName")+"</td>");
                    out.println("<td>$"+resultSet.getString("colStockPrice")+"</td>");
                    out.println("<td>"+resultSet.getString("colStockAmt")+"</td>");
                    out.println("</tr>"); 
                    totalPortfolioValue+= Double.parseDouble(resultSet.getString("colStockValue"));
                }
                
                out.println("</table><br/><br/>");
                
                out.println("<strong>Total Portfolio Value:$ "+ totalPortfolioValue+"</strong><br>" );
                if(moneyAdd != null){
                    out.println("<strong>"+moneyAdd+"</strong>");
                }

                out.println("would you like to add money to your account?<br>");
                out.println("<form action =\"holdingsPage\" method=\"post\" name =\"form2\">");
                out.println("<input type=\"hidden\" name=\"addCheck\" value=\"yes\">");
                out.println("<input type=\"number\" name=\"amount\" min=\"0\" max=\"10000\" step=\"100\">");
                out.println("<input type=\"submit\" value=\"Add Money\">");
                out.println("</form>");

                out.println("</section>");
                out.println("</body>");
                out.println("</html>");
                if (request.getParameter("amount")!=null&&request.getParameter("amount").equals(0)){
                    out.println("no money was added to your account");
                }  
            }
            catch(Exception e)
                {
                    out.println("DATABASE PROBLEM: " + e);
                }
        }
    }
  
}

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
