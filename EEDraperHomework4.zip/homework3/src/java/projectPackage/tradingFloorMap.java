/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectPackage;
import java.util.HashMap;

/**
 *
 * @author jdraper6
 */
public class tradingFloorMap {
    
             public static final HashMap<String, Investor> theTradingFloorMap = new HashMap<String, Investor>();
    
}
 